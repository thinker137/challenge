Page({
  data: {
    directions: [
      {
        name: '本部 -> 基地',
        weekdaysTimes: ['07:00', '12:40', '19:00'],
        weekendsTimes: ['19:00']
      },
      {
        name: '基地 -> 本部',
        weekdaysTimes: ['06:40', '12:20', '17:30'],
        weekendsTimes: ['06:40']
      }
    ],
    selectedDirection: '',
    selectedDate: '',
    selectedTime: '',
    selectedTimeOptions: [],
    bookingSuccess: false,
    bookingId: '',
    userId: '',
    nickName: '',
    role: ''
  },

  onLoad(options) {
    this.setData({
      userId: decodeURIComponent(options.userId || ''),
      nickName: decodeURIComponent(options.nickName || ''),
      role: decodeURIComponent(options.role || '')
    });
  },

  onDirectionChange(e) {
    const selectedIndex = e.detail.value;
    const selectedDirection = this.data.directions[selectedIndex];
    this.setData({
      selectedDirection: selectedDirection.name,
      selectedDate: '', // 重置选择的日期
      selectedTime: '', // 重置选择的时间
      selectedTimeOptions: []
    });
  },

  onDateChange(e) {
    const selectedDate = e.detail.value;
    const selectedDirectionObj = this.data.directions.find(d => d.name === this.data.selectedDirection);
    const selectedDateObj = new Date(selectedDate);
    const isWeekend = selectedDateObj.getDay() === 0 || selectedDateObj.getDay() === 6;

    const timeOptions = isWeekend ? selectedDirectionObj.weekendsTimes : selectedDirectionObj.weekdaysTimes;

    this.setData({
      selectedDate,
      selectedTime: '', // 重置选择的时间
      selectedTimeOptions: timeOptions
    });
  },

  onTimeChange(e) {
    const selectedIndex = e.detail.value;
    const selectedTime = this.data.selectedTimeOptions[selectedIndex];
    this.setData({ selectedTime });
  },

  submitBooking() {
    const { selectedDirection, selectedDate, selectedTime, userId, nickName } = this.data;

    if (!selectedDirection || !selectedDate || !selectedTime) {
      wx.showToast({
        title: '请填写完整预约信息',
        icon: 'none'
      });
      return;
    }

    const allBookings = wx.getStorageSync('allBookings') || [];

    const hasBooked = allBookings.some(item => item.userId === userId && item.date === selectedDate);


    const randomId = 'R' + Math.floor(1000 + Math.random() * 9000);

    const newBooking = {
      userId,
      nickName,
      direction: selectedDirection,
      date: selectedDate,
      time: selectedTime,
      bookingId: randomId
    };

    allBookings.push(newBooking);
    wx.setStorageSync('allBookings', allBookings);

    this.setData({
      bookingSuccess: true,
      bookingId: randomId
    });

    wx.showToast({
      title: '预约成功',
      icon: 'success'
    });
  },

  goToMyBookings() {
    wx.navigateTo({
      url: `/pages/mybookings/mybookings?userId=${encodeURIComponent(this.data.userId)}`
    });
  }
});