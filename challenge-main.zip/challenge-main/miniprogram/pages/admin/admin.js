Page({
  data: {
    busList: [
      { 
        id: 1,
        name: '本部 -> 基地',
        direction: '本部',
        departureTime: '07:00',
        seats: 40
      },
      { 
        id: 2,
        name: '本部 -> 基地',
        direction: '本部',
        departureTime: '12:40',
        seats: 40
      },
      { 
        id: 3,
        name: '本部 -> 基地',
        direction: '本部 -> 基地',
        departureTime: '19:00',
        seats: 40
      },
      { 
        id: 4,
        name: '基地 -> 本部',
        direction: '基地 -> 本部',
        departureTime: '06:40',
        seats: 40
      },
      { 
        id: 5,
        name: '基地 -> 本部',
        direction: '基地 -> 本部',
        departureTime: '12:20',
        seats: 40
      },
      { 
        id: 6,
        name: '基地 -> 本部',
        direction: '基地 -> 本部',
        departureTime: '17:30',
        seats: 40
      }
    ],
    newBusName: '',
    newBusDirection: '',
    newBusTime: '',
    newBusSeats: '',
    editBusId: null, // 用于标记正在编辑的班车 ID
    editBusSeats: '' // 用于存储正在编辑的班车座位数
  },

  onInputBusName(e) {
    this.setData({ newBusName: e.detail.value });
  },

  onInputBusDirection(e) {
    this.setData({ newBusDirection: e.detail.value });
  },

  onInputBusTime(e) {
    this.setData({ newBusTime: e.detail.value });
  },

  onInputBusSeats(e) {
    this.setData({ newBusSeats: e.detail.value });
  },

  addBus() {
    const { newBusName, newBusDirection, newBusTime, newBusSeats, busList } = this.data;
    if (!newBusName.trim() || !newBusDirection.trim() || !newBusTime.trim() || !newBusSeats.trim()) {
      wx.showToast({
        title: '请输入完整信息',
        icon: 'none'
      });
      return;
    }

    const newId = busList.length > 0 ? busList[busList.length - 1].id + 1 : 1;
    const newList = [...busList, { 
      id: newId, 
      name: newBusName,
      direction: newBusDirection,
      departureTime: newBusTime,
      seats: parseInt(newBusSeats)
    }];

    this.setData({
      busList: newList,
      newBusName: '',
      newBusDirection: '',
      newBusTime: '',
      newBusSeats: ''
    });

    wx.showToast({
      title: '添加成功',
      icon: 'success'
    });
  },

  deleteBus(e) {
    const busId = e.currentTarget.dataset.id;
    const newList = this.data.busList.filter(b => b.id !== busId);
    this.setData({ busList: newList });
    wx.showToast({ title: '删除成功', icon: 'success' });
  },

  startEditBus(e) {
    const busId = e.currentTarget.dataset.id;
    const bus = this.data.busList.find(b => b.id === busId);
    this.setData({
      editBusId: busId,
      editBusSeats: bus.seats.toString()
    });
  },

  onEditBusSeatsInput(e) {
    this.setData({ editBusSeats: e.detail.value });
  },

  saveEditBus() {
    const { editBusId, editBusSeats, busList } = this.data;
    if (!editBusId || !editBusSeats.trim()) {
      return;
    }
    const newList = busList.map(bus => {
      if (bus.id === editBusId) {
        return { ...bus, seats: parseInt(editBusSeats) };
      }
      return bus;
    });
    this.setData({
      busList: newList,
      editBusId: null,
      editBusSeats: ''
    });
    wx.showToast({ title: '修改成功', icon: 'success' });
  },

  cancelEditBus() {
    this.setData({
      editBusId: null,
      editBusSeats: ''
    });
  },

  viewBookings() {
    const allBookings = wx.getStorageSync('allBookings') || [];
    wx.navigateTo({
      url: `/pages/admin/bookings/bookings?allBookings=${encodeURIComponent(JSON.stringify(allBookings))}`
    });
  },

  markMissedRidersx() {
    const allBookings = wx.getStorageSync('allBookings') || [];
    const userStats = wx.getStorageSync('userStats') || {};
  
    const today = new Date().toISOString().slice(0, 10);
    const missed = allBookings.filter(b => b.date === today && !b.checkedIn);
  
    missed.forEach(b => {
      const uid = b.userId;
      if (!userStats[uid]) {
        userStats[uid] = { cancelHistory: [], missedCount: 0, bannedUntil: '' };
      }
      userStats[uid].missedCount += 1;
  
      if (userStats[uid].missedCount >= 3) {
        const banDate = new Date();
        banDate.setDate(banDate.getDate() + 7);
        userStats[uid].bannedUntil = banDate.toISOString().slice(0, 10);
      }
    });
  
    wx.setStorageSync('userStats', userStats);
    wx.showToast({ title: '处理完成', icon: 'success' });
  }
});